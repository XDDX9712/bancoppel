<?php
header("Location: /");
?>