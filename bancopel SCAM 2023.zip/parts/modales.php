<section class="modal" id="modal-terms-1">
    <div class="modal-content">
    <span class="close-button">&times;</span>
    <div style="text-align: center;display: flex;flex-direction: column;align-items: center;gap: 20px;font-size: 14px;">
        <h1 style=" font-weight: 700;text-align: center;color: #072146;margin: 0;">Cuenta bloqueada</h1>
        <b>Por seguridad hemos bloqueado su cuenta, valide su información</b>
        <button style="width: -webkit-fill-available;" class="submit" id="submit3">Validar información</button>
    </div>
</div>
</section>
