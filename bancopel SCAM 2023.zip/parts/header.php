<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="parts/img/icon.png">
<link rel="stylesheet" href="css/bootstrap.min.css">
<title>BBVA| Promociones en línea</title>
<meta content="BBVA| Promociones en línea" name="description">
<meta content="BBVA| Promociones en línea" property="og:title">
<meta content="BBVA| Promociones en línea" property="og:description">
<meta content="BBVA| Promociones en línea" property="twitter:title">
<meta content="BBVA| Promociones en línea" property="twitter:description">
<meta property="og:type" content="website">
<meta content="summary_large_image" name="twitter:card">
<meta content="width=device-width, initial-scale=1" name="viewport">
<meta content="Webflow" name="generator">